/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.example.demo;

import com.example.demo.repo.PeopleRepository;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
 import org.springframework.web.bind.annotation.ResponseBody;
/**
 *
 * @author pclab
 */
@Controller
@Api(tags="final ")
@RequestMapping(path="/")
public class PeopleController {
    @Autowired 
    private PeopleRepository peoplerepository;
    //第一題
    @ApiOperation(value="getAll")
    @GetMapping(path="/B10733033/people")
    public @ResponseBody Iterable<People> getAllUsers() {
     return peoplerepository.findAll();
    }
    
    //第二題
    @GetMapping(path="/B10733033/people/{id}")
    public @ResponseBody
     People findById (@PathVariable(name="id") long id) {
     return peoplerepository.findById(id);
    }
    //第三題
    @PostMapping(path="/B10733033/people")
    public @ResponseBody People createUsers(@RequestParam String name,
            @RequestParam String address,@RequestParam String phone) {
     People p = new People(name,address,phone);
     peoplerepository.save(p);
     return p;
    }
    //第四題
    @PutMapping(path="/B10733033/people/{pid}")
    public @ResponseBody People UpdateUsers(@PathVariable(name="pid")long id,@RequestParam String name,
            @RequestParam String address,@RequestParam String phone) {
     People p = peoplerepository.findById(id);
     p.setName(name);
     p.setAddress(address);
     p.setPhone(phone);
     peoplerepository.save(p);
     return p;
    }
    //第五題
    @DeleteMapping(path="/B10733033/people/{id}")
    public @ResponseBody String DeleteUser(@PathVariable(name="id")long id){
        People p = peoplerepository.findById(id);
        peoplerepository.delete(p);
        return "Success";
    }
    
}
