/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.example.demo;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
/**
 *
 * @author pclab
 */
@Entity
public class People {
    @Id
    @GeneratedValue(strategy= GenerationType.AUTO)
    private Long pid;
    private String name;
    private String address;
    private String phone;
    protected People(){}
    public People(String name,String address,String phone){
        
        this.name = name;
        this.address = address;
        this.phone = phone;
    }
    Long getId(){
        return pid;
    }
    String getName(){
        return name;
    }
    String getAddress(){
        return address;
    }
    String getPhone(){
        return phone;
    }

    void setName(String name) {
        this.name = name; //To change body of generated methods, choose Tools | Templates.
    }

    void setAddress(String address) {
        this.address = address;
//throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    void setPhone(String phone) {
        this.phone = phone;
//throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    @Override
    public String toString() {
        return String.format(
    "People[pid=%d, name='%s', address='%s',phone='%s']",
    pid,name, address, phone);
    }
}
